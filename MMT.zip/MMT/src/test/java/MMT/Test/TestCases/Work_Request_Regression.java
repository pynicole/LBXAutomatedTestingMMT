package  MMT.Test.TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import org.openqa.selenium.chrome.ChromeDriver;
//import java.io.File;
import java.time.Duration;
//import org.openqa.selenium.By;
//import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
//import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import MMT.Test.PageObjects.PO_Common;
import MMT.Test.TestCases.Utils.BrowserManager;

public class Work_Request_Regression
{
	@Test
	@Parameters ({"browser", "url", "username", "password"})
	public void Work_Request_Regression_Test(String browser, String url, String username, String password) throws InterruptedException {
		
		// Creates instance of driver based on specified browser and url
		WebDriver driver = BrowserManager.getDriver(browser,url);
		// Initializing Page Object for PO_Common class using provided driver instance
		PO_Common obj = PageFactory.initElements(driver, PO_Common.class);

		try {

			obj.Step1WRR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step2WRR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step3WRR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step4WRR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step5WRR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step6WRR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step7WRR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step8WRR();
			obj.takeScreenshotWithTaskbar();
			
			
			//Thread.sleep(5000);
			//obj.takeScreenshotWithTaskbar();
			
		} catch (PO_Common.stepFailure e) {
			driver.quit();
			Assert.fail("Test failed due to step error.");
		}
		
		
		//This timeout is used to specify the time the driver should wait while 
		//searching for an element if it is not immediately present.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.close();
	

	}

}


