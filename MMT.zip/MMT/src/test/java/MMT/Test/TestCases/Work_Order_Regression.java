package  MMT.Test.TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import org.openqa.selenium.chrome.ChromeDriver;
//import java.io.File;
import java.time.Duration;
//import org.openqa.selenium.By;
//import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
//import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import MMT.Test.PageObjects.PO_Common;
import MMT.Test.TestCases.Utils.BrowserManager;

public class Work_Order_Regression
{
	@Test
	@Parameters ({"browser", "url", "username", "password"})
	public void Work_Order_Regression_Test(String browser, String url, String username, String password) throws InterruptedException {
		
		// Creates instance of driver based on specified browser and url
		WebDriver driver = BrowserManager.getDriver(browser,url);
		// Initializing Page Object for PO_Common class using provided driver instance
		PO_Common obj = PageFactory.initElements(driver, PO_Common.class);

		try {

			obj.Step1WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step2WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step3WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step4WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step5WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step6WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step7WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step8WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step9WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step10WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step11WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step12WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step13WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step14WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step15WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step16WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step17WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step18WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step19WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step20WOR();
			obj.takeScreenshotWithTaskbar();
			
			obj.Step21WOR();
			obj.takeScreenshotWithTaskbar();
			
			
			//Thread.sleep(5000);
			//obj.takeScreenshotWithTaskbar();
			
		} catch (PO_Common.stepFailure e) {
			driver.quit();
			Assert.fail("Test failed due to step error.");
		}
		
		
		//This timeout is used to specify the time the driver should wait while 
		//searching for an element if it is not immediately present.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.close();
	

	}

}


