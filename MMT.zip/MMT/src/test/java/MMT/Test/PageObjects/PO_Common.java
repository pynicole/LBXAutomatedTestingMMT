package MMT.Test.PageObjects;

import java.time.Duration;
import java.awt.AWTException;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import junit.framework.Assert;

//Define the class PO_Common. It represents a common base class for Page Objects.
public class PO_Common 
{
		// Declare a member variable "driver" of type WebDriver. It will hold the web driver instance used for automation.
		WebDriver driver;
		
		// Define a constructor for the PO_Common class. It takes a WebDriver object as a parameter.
		public PO_Common(WebDriver driver) {
			// Assign the provided WebDriver instance to the member variable "driver".
			this.driver = driver;
		}	
		
		// Declare a private static member variable "timestamp" of type String.
		private static String timestamp;
		
		
	    public class stepFailure extends RuntimeException {
	        public stepFailure(String message) {
	            super(message);
	        }
	    }
		
		
		

		
		
//----- PAGE OBJECTS -------------------------------------------------------------------------------------//
//-- This is where you define the specific button, field, or section on the webpage that you want to -----//
//-- interact with. Ideally you want to section them to what type of object and in alphabetical order ----//
//-- so you can find them easily. Below is an example on how to define an object. ------------------------//
//--------------------------------------------------------------------------------------------------------//
// Put a comment here about what the object is and on what specific page                                  //
// @FindBy(put what html tag you want to reference: should be id/name/or xpath (xpath most preferred)     //
// private WebElement insertNameOfObjectHere;                                                             //
//--------------------------------------------------------------------------------------------------------//

	    
	    
//****** Hexagon Dev website section ******//	
	    
	    //Hexagon: Username field
	    @FindBy(xpath="//*[@id=\"textfield-1034-inputEl\"]")
	    private WebElement HexUsername;
	    
	    //Hexagon: Password field
	    @FindBy(xpath="//*[@id=\"textfield-1035-inputEl\"]")
	    private WebElement HexPassword;
	    
	    //Hexagon: Login button
	    @FindBy(xpath="//*[@id=\"button-1037\"]")
	    private WebElement HexLoginButton;
	    
	    //Hexagon: Work tab
	    @FindBy(xpath="//*[@id=\"button-1044-btnWrap\"]")
	    private WebElement HexWorkTab;
	    
	    //Hexagon: Work Orders under Work tab
	    @FindBy(xpath="//*[@id=\"menuitem-1080-textEl\"]")
	    private WebElement HexWorkOrders;
	    
	    //Hexagon: Status filter
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[1]/div/div/div/div/div/div[3]/div/div/div[3]/div/div/div/div[1]/div/div/input")
	    private WebElement HexStatusFilter;
	    
	    //Hexagon: Run button on Work Orders screen
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[1]/div/div/div/div/div/div[1]/div/div/a[3]/span/span/span[2]")
	    private WebElement HexRun;
	    
	    
	    //------------Equipment Regression Test Script---------------//
	    //Hexagon: Equipment dropdown on front page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[1]/div/div/div[2]/div/div/a[4]/span/span")
	    private WebElement EquipmentDropdown;
	    
	    //Hexagon: Assets on Equipment dropdown on front page
	    @FindBy(xpath="/html/body/div[5]/div/div/div[2]/div/div[4]/a/span")
	    private WebElement AssetsOnEquipmentDropdown;
	    
	    //Hexagon: New record button on Assets screen
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[3]/span/span/span[1]")
	    private WebElement NewRecordOnAssets;
	    
	    //Hexagon: Asset ID field
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[1]/div/div/div/div/div[1]/div/table/tbody/tr/td[1]/div/div[2]/div/div/input")
	    private WebElement AssetIDField;
	    
	    //Hexagon: Asset description field
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[1]/div/div/div/div/div[1]/div/table/tbody/tr/td[2]/div/div[2]/div/div/input")
	    private WebElement AssetDescription;
	    
	    //Hexagon: Asset department field
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr[2]/td[1]/div/div/div/div/div[2]/div/div[1]/input")
	    private WebElement AssetDepartment;
	    
	    //Hexagon: Asset status field
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[2]/div/div/div/div[2]/div[2]/div/div[1]/input")
	    private WebElement AssetStatus;
	    
	    //Hexagon: Asset status error OK button
	    @FindBy(xpath="/html/body/div[8]/div/div[2]/div/div/a[1]/span/span/span[2]")
	    private WebElement AssetStatusOK;
	    
	    //Hexagon: Asset status field dropdown button
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[2]/div/div/div/div[2]/div[2]/div/div[2]")
	    private WebElement AssetStatusDropdown;
	    
	    //Hexagon: Asset status field removed from service
	    @FindBy(xpath="/html/body/div[9]/div[1]/ul/li[4]")
	    private WebElement AssetStatusRFS;
	    
	    //Hexagon: Asset status field decommissioned
	    @FindBy(xpath="/html/body/div[9]/div[1]/ul/li[1]")
	    private WebElement AssetStatusD;
	    
	    //Hexagon: Asset parent asset field
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[2]/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr/td/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement AssetParentAsset;
	    
	    //Hexagon: Asser part dropdown field
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[3]/td/div/div[1]/div/div/div[2]/div")
	    private WebElement AssetPartDropdown;
	    
	    //Hexagon: Asser part field
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[3]/td/div/div[2]/div/table/tbody/tr/td[1]/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement AssetPart;
	    
	    //Hexagon: Asset location field
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[2]/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr/td/div/div/div/div[10]/div[2]/div/div[1]/input")
	    private WebElement AssetLocation;
	    
	    //Hexagon: Asset expand right view button
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/div[5]/div/div/table/tbody/tr/td[3]/a/span/span/span[1]")
	    private WebElement AssetExpandRightView;
	    
	    //Hexagon: Asset save button
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[2]/span/span/span[1]")
	    private WebElement AssetSaveButton;
	    
	    //Hexagon: Asset search field on expand right view
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[1]/div/div/div/div[2]/div/div[3]/div/div/div[1]/div/div/div/div[1]/div/div/input")
	    private WebElement AssetSearchField;
	    
	    //Hexagon: Asset split view button
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/div[5]/div/div/table/tbody/tr/td[2]/a/span/span/span[1]")
	    private WebElement AssetSplitView;
	    
	    //Hexagon: Asset structure tab button
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div[2]/div/a[5]")
	    private WebElement AssetStructure;
	    
	    
	  //------------Work Request Regression Test Script---------------//
	    //Hexagon: Operations dropdown menu on front page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[1]/div/div/div[2]/div/div/a[5]/span/span")
	    private WebElement OperationsDropdown;
	    
	    //Hexagon: Call Center selection on Operations dropwdown
	    @FindBy(xpath="/html/body/div[5]/div/div/div[2]/div/div[2]/a/span")
	    private WebElement OperationsCallCenter;
	    
	    //Hexagon: New record button on call center page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[3]/span/span/span[1]")
	    private WebElement CallCenterNewRecord;
	    
	    //Hexagon: Organization field on call center new record page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr/td[2]/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr/td/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement CallCenterOrganization;
	    
	    //Hexagon: Equipment field on call center new record page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr/td[1]/div/table/tbody/tr[4]/td/div/div[2]/div/table/tbody/tr[3]/td/div/div/div/div[1]/div[1]/div/table/tbody/tr/td[1]/div/div[2]/div/div[1]/input")
	    private WebElement CallCenterEquipment;
	    
	    //Hexagon: Service code field on call center new record page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr/td[1]/div/table/tbody/tr[4]/td/div/div[2]/div/table/tbody/tr[3]/td/div/div/div/div[3]/div[1]/div/table/tbody/tr/td[1]/div/div[2]/div/div[1]/input")
	    private WebElement CallCenterServiceCode;
	    
	    //Hexagon: Location field on call center new record page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr/td[1]/div/table/tbody/tr[4]/td/div/div[2]/div/table/tbody/tr[3]/td/div/div/div/div[2]/div[1]/div/table/tbody/tr/td[1]/div/div[2]/div/div[1]/input")
	    private WebElement CallCenterLocation;
	    
	    //Hexagon: Location field on call center new record page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr/td[1]/div/table/tbody/tr[3]/td/div/div[1]/div/div/div[7]/div")
	    private WebElement CallCenterContactInfoDropdown;
	    
	    //Hexagon: Email field on call center new record page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr/td[1]/div/table/tbody/tr[3]/td/div/div[2]/div/table/tbody/tr[4]/td/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement CallCenterEmail;
	    
	    //Hexagon: Save button on call center new record page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[2]/span/span/span[1]")
	    private WebElement CallCenterSaveButton;
	    
	    //Hexagon: Asset status field decommissioned
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[1]/div/div/div[2]/div/div/a[2]/span/span")
	    private WebElement WorkDropdown;
	    
	    //Hexagon: Work requests selection under Work dropdown
	    @FindBy(xpath="//*[@id=\"menuitem-1080\"]")
	    private WebElement WorkWorkRequests;
	    
	    //Hexagon: Requested by field on work request page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/div/div/div[3]/div/div/div[1]/div[2]/div/table/tbody/tr/td/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkRequestsRequestedBy;
	    
	    //Hexagon: Save button on work requests page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[2]/span/span/span[1]")
	    private WebElement WorkRequestsSaveButton;
	    
	    //Hexagon: Administration dropwdown
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[1]/div/div/div[2]/div/div/a[6]/span/span/span[2]")
	    private WebElement AdministrationDropdown;
	    
	    //Hexagon: E-mail messenger under Administration dropdown
	    @FindBy(xpath="//*[@id=\"menuitem-1118-textEl\"]")
	    private WebElement AdministrationEmailMessenger;
	    
	    //Hexagon: E-mail viewer under Administration dropdown
	    @FindBy(xpath="//*[@id=\"menuitem-3015\"]")
	    private WebElement AdministrationEmailViewer;
	    
	    //Hexagon: Work orders split screen button
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/div[5]/div/div/table/tbody/tr/td[2]/a/span/span/span[1]")
	    private WebElement WorkOrdersSplitScreen;
	    
	    //Hexagon: Status dropdown on work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[3]/td/div/div[2]/div/table/tbody/tr/td[2]/div/div/div/div[1]/div[2]/div/div[3]")
	    private WebElement WorkOrdersStatusDropdown;
	    
	    //Hexagon: Status field on work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[3]/td/div/div[2]/div/table/tbody/tr/td[2]/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrdersStatus;
	    
	    //Hexagon: Save button on work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[2]/span/span/span[1]")
	    private WebElement WorkOrdersSaveButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="//*[@id=\"button-1013-btnInnerEl\"]")
	    private WebElement WorkOrdersOKError;
	    
	    //Hexagon: Reset button for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[8]/span/span/span[1]")
	    private WebElement WorkOrdersResetButton;
	    
	    //Hexagon: Reset button for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[7]/td/div/div[2]/div/table/tbody/tr[1]/td[1]/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrdersRejectedReason;

	    
	//------------Work Order Regression Test Script---------------//
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[1]/div/div/div/div/div/div[3]/div/div/div[3]/div/div/div/div[1]/div/div/input")
	    private WebElement WorkOrderStatusSearch;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[1]/div/div/div/div/div/div[3]/div/div/div[11]/div/div/div/div[1]/div/div/input")
	    private WebElement WorkOrderPrioritySearch;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/div[5]/div/div/table/tbody/tr/td[2]/a/span/span/span[1]")
	    private WebElement WorkOrderSplitScreenButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[1]/div/div/div/div/div/div[1]/div/div/a[3]/span/span/span[2]")
	    private WebElement WorkOrderRunButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[3]/td/div/div[2]/div/table/tbody/tr/td[2]/div/div/div/div[1]/div[2]/div/div[3]")
	    private WebElement WorkOrderStatusDropdown;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[3]/td/div/div[2]/div/table/tbody/tr/td[2]/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderStatusField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div[4]/a/span")
	    private WebElement WorkOrderMoreDropdown;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[2]/div/div/div[2]/div/div[5]/a/span")
	    private WebElement WorkOrderPartsTab;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[1]/td/div/div/div/div[1]/div[1]/div/table/tbody/tr/td[1]/div/div[2]/div/div[1]/input")
	    private WebElement WorkOrderPartField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[1]/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderPlannedQtyField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[1]/div/div/div/div[2]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderReservedQtyField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[2]/div/div/div/div[2]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderStoreField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[3]/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderPlannedSourceField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[1]/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr/td[1]/div/table/tbody/tr[1]/td/div/div/div/div[3]/div[1]/div/table/tbody/tr/td[1]/div/div[2]/div/div[1]/input")
	    private WebElement WorkOrderLocationField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[2]/span/span/span[1]")
	    private WebElement WorkOrderSaveButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div[2]/div/a[3]/span[1]/span/span[2]")
	    private WebElement WorkOrderActivitiesTab;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[1]/td/div/div/div/div[2]/div[2]/div/div[2]")
	    private WebElement WorkOrderPartsTabActivityDropdown;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[1]/div/div/div/div[2]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderActivitiesTradeField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[1]/div/div/div/div[3]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderActivitiesPeopleRequiredField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[2]/div/div/div/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[1]/div/div/div/div[4]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderActivitiesEstimatedHoursField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div[2]/div/a[1]")
	    private WebElement WorkOrderRecordViewTab;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div[2]/div/a[6]/span[1]/span/span[2]")
	    private WebElement WorkOrderScheduledLaborTab;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[3]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr/td/div/div[2]/div/table/tbody/tr[2]/td[2]/div/div/div/div[1]/div[2]/div/div[2]")
	    private WebElement WorkOrderScheduledLaborActivityDropdown;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[8]/div/div[2]/div/div/a[2]/span/span/span[2]")
	    private WebElement WorkOrderScheduledLaborYesButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div[2]/div/a[7]/span[1]/span/span[2]")
	    private WebElement WorkOrderDocumentsTab;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[4]/div/div/div/div/div/div/div/div/div[1]/div/div/a[1]")
	    private WebElement WorkOrderDocumentsAddButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[11]/div[2]/div[1]/div[1]/div/div[2]/div/div/div/div/div/div/div/div/div[2]/div/div/div/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderDocumentField;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[11]/div[2]/div[2]/div/div/a[2]/span/span/span[2]")
	    private WebElement WorkOrderDocumentSaveButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[4]/div/div/div/div/div/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div[2]/table[2]/tbody/tr/td/div/div[3]")
	    private WebElement WorkOrderDocumentClick;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[12]/div[2]/div[2]/div/div/a[1]/span/span/span[2]")
	    private WebElement WorkOrderDocumentView;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[12]/div[2]/div[2]/div/div/a[1]/span/span/span[2]")
	    private WebElement WorkOrderDocumentCloseButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/div[5]/div/div/table/tbody/tr/td[3]/a/span/span/span[1]")
	    private WebElement WorkOrderExpandRight;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div[2]/div/a[9]/span[1]/span/span[2]")
	    private WebElement WorkOrderChecklistTab;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[5]/div/div/div/div/div/div[1]/div/div/div/div/div/div/div/div[1]/div[2]/div/table/tbody/tr[2]/td[1]/div/div/div/div[1]/div[2]/div/div[2]")
	    private WebElement WorkOrderChecklistPerformedBy;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[13]/div[2]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div/div[2]/div/table/tbody/tr/td/div/div/div/div[2]/div[2]/div/div/input")
	    private WebElement WorkOrderChecklistPassword1;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[13]/div[2]/div[2]/div/div/a[1]/span/span/span[2]")
	    private WebElement WorkOrderChecklistOkButton1;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[5]/div/div/div/div/div/div[1]/div/div/div/div/div/div/div/div[1]/div[2]/div/table/tbody/tr[2]/td[3]/div/div/div/div[1]/div[2]/div/div[2]")
	    private WebElement WorkOrderChecklistReviewedBy;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[5]/div/div/div/div/div/div[1]/div/div/div/div/div/div/div/div[1]/div[2]/div/table/tbody/tr[2]/td[3]/div/div/div/div[1]/div[2]/div/div[2]")
	    private WebElement WorkOrderChecklistPassword2;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[13]/div[2]/div[2]/div/div/a[1]/span/span/span[2]")
	    private WebElement WorkOrderChecklistOkButton2;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div[2]/div/a[4]/span[1]/span/span[2]")
	    private WebElement WorkOrderBookLaborTab;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[6]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[1]/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderBookLaborDateWorked;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[6]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[2]/td[1]/div/div/div/div[3]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderBookLaborHoursWorked;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[8]/div/div[2]/div/div/a[2]/span/span/span[2]")
	    private WebElement WorkOrderBookLaborYesButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[6]/div/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/table/tbody/tr[1]/td/div/div[2]/div/table/tbody/tr[1]/td/div/div/div/div[1]/div[1]/div/table/tbody/tr/td[1]/div/div[2]/div/div[1]/input")
	    private WebElement WorkOrderBookLaborEmployee;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[1]/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr/td[2]/div/table/tbody/tr/td/div/div/div/div[3]/div[2]/div/div[2]")
	    private WebElement WorkOrderRecordViewSignature;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[12]/div[2]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div/div[2]/div/table/tbody/tr/td/div/div/div/div[2]/div[2]/div/div/input")
	    private WebElement WorkOrderRecordViewPassword;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[12]/div[2]/div[2]/div/div/a[1]/span/span/span[2]")
	    private WebElement WorkOrderRecordViewOkButton;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[1]/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[7]/td/div/div[2]/div/table/tbody/tr[1]/td[1]/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderRejectedReason;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[3]/span/span/span[1]")
	    private WebElement WorkOrderNewRecord;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[1]/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr/td[2]/div/table/tbody/tr/td/div/div/div/div[1]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderOrganization;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[1]/div/div/div/table/tbody/tr[1]/td/div/table/tbody/tr/td/div/div/div/table/tbody/tr/td[1]/div/table/tbody/tr[1]/td/div/div/div/div[2]/div[1]/div/table/tbody/tr/td[1]/div/div[2]/div/div[1]/input")
	    private WebElement WorkOrderEquipment;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[1]/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[3]/td/div/div[2]/div/table/tbody/tr/td[1]/div/div/div/div[3]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderPriority;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[3]/div/div/div/div/div/div[1]/div[1]/div[2]/div[1]/div/div/div/table/tbody/tr[2]/td[1]/div/table/tbody/tr[7]/td/div/div[2]/div/table/tbody/tr[1]/td[2]/div/div/div/div[2]/div[2]/div/div[1]/input")
	    private WebElement WorkOrderCancelReason;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[10]/span/span/span[1]")
	    private WebElement WorkOrderPrintPreview;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[4]/div/div/div[2]/div/div[2]/a/span")
	    private WebElement WorkReports;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[13]/div/div/div[2]/div/div[4]/a/span")
	    private WebElement WorkReportsPrintWorkOrders;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[13]/div/div/div[2]/div/div[4]/a/span")
	    private WebElement WorkReportsPrintWorkOrdersComprehensive;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div/div/div/div/div/div/div/div/div[2]/div/div/div/div[2]/div/div/div/div[1]/div/div/div[2]/div[2]/div/div[1]/input")
	    private WebElement WorkReportsWorkOrder;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[2]/div/div/a[9]/span/span/span[1]")
	    private WebElement WorkReportsPrintRecord;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[4]/div/div/div[2]/div/div[1]/a/span")
	    private WebElement WorkSetup;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="/html/body/div[22]/div/div/div[2]/div/div[1]/a/span")
	    private WebElement WorkSetupEmployees;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="xxxx")
	    private WebElement test6437;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="xxxx")
	    private WebElement test6537;
	    
	    //Hexagon: OK button on error for work orders page
	    @FindBy(xpath="xxxx")
	    private WebElement test6637;
		
//----- METHODS ------------------------------------------------------------------------------------------//
//-- This is where you define the specific methods (actions) that you want to do to the webpage. ---------//
//-- Ideally you want to section them to what type of method it is and in alphabetical order -------------//
//-- so you can find them easily. Below is an example on how to define a method. -------------------------//
//--------------------------------------------------------------------------------------------------------//
// Put a comment here about what the action is to what page objects                                       //
// public void nameOfActionHere() {                                                                       //
//     try {                                                                                              //
//	        nameOfPageObjectYouWant.click() or .sendKeys(wordYouWantToEnter)                              //
//	  	    refreshTimestamp();   (used to get the current time)                                          //
//	  	    Reporter.log("This should be the "Expected" result of the action being done", true);          //
//  	    Reporter.log("This should be the "Actual" result of the action being done", true);            //
//  	    Reporter.log(timestamp, true);    (timestamps the action to the current time)                 //
//     } catch (Exception e) {                                                                            //
//          e.printStackTrace();    (will output the error if an error occurs)                            //
//          refreshTimestamp();                                                                           //
//	  	    Reporter.log("This should be the "Expected" result of the action being done", true);          //
//		    Reporter.log("Step failed.", true);                                                           //
//		    Reporter.log(timestamp, true);                                                                //
//          throw new stepFailure("Step failed."); (stops the test and marks as failure)                  //
//     }                                                                                                  //
// }                                                                                                      //
//--------------------------------------------------------------------------------------------------------// 
	  	
	  	
//****** Commonly used methods ******//		
	    
	    public void findElement(String text, String afterNum, String action, String inputKey) {
	  	    // Find the element using its text
	  	    WebElement element = driver.findElement(By.xpath("//*[text()='" + text + "']"));

	  	    // Retrieve the id attribute from the WebElement
	  	    String elementId = element.getAttribute("id");

	  	    // Define a pattern to find the word followed by hyphen and four digits
	  	    Pattern pattern = Pattern.compile("(\\w+)-?(\\d{4})");
	  	    Matcher matcher = pattern.matcher(elementId);
	  	    
	  	    System.out.println("ElementID: " + elementId);
	  	    System.out.println("Pattern: " + pattern);
	  	    System.out.println("Matcher: " + matcher);
	  	    
	  	    // Check if the pattern is found
	  	    if (matcher.find()) {
	  	        // Extract the group of the identifier and four digits
	  	        String identifier = matcher.group(1);
	  	        String fourDigits = matcher.group(2);

	  	        // Build the new XPath with the extracted identifier and digits
	  	        String newXpath = "//*[@id='" + identifier + "-" + fourDigits + afterNum + "']";
	  	        
	  	        // Use the new XPath to find the element
	  	        WebElement newElement = driver.findElement(By.xpath(newXpath));
	  	        
	  	        System.out.println("Element found: " + newElement);      
	  	        
	  	        if (action.equals("click")) {
	  	            newElement.click();
	  	            System.out.println("Element click");
	  	        } else if (action.equals("sendkeys")) {
	  	            newElement.sendKeys(inputKey);
	  	            System.out.println("Element sendkeys");
	  	        }
	  	    } else {
	  	        System.out.println("No matching pattern found in the ID.");
	  	    }
	  	}
	  	
	  	
	  	private static void refreshTimestamp() {
	        // Update the timestamp with the current date and time
	        timestamp = new SimpleDateFormat("dd-MMM-yy HH:mm:ss").format(new Date());
	    }
	  	
	  	public void takeScreenshotWithTaskbar() {
	  	    try {
	  	        // Create a Robot object to capture the screen pixels
	  	        Robot robot = new Robot();

	  	        // Determine the size of the screen
	  	        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());

	  	        // Capture the screen shot of the entire screen
	  	        BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
	  	        
	  	        // Generate a unique file name based on the current timestamp
	  	        String fileName = "screenshot_" + getTimestamp() + ".jpg";

	  	        File destination = new File("C:\\Users\\LBX Admin\\Automated Testing Screenshots\\" + fileName);

	  	        // Save the screenshot to the specified location
	  	        ImageIO.write(screenFullImage, "jpg", destination);
	  	        
	  	        System.out.println("Screenshot captured: " + destination.getAbsolutePath());
	  	        refreshTimestamp();

	  	        // Convert the screenshot to Base64 encoded string
	  	        String base64Screenshot = convertToBase64(destination);

	  	        // Embed the screenshot image into the TestNG report using <img> tag with Base64 data
	  	        String imgTag = "<img src=\"data:image/jpeg;base64," + base64Screenshot + "\" alt=\"Screenshot\" height=\"250\" />";
	  	        Reporter.log("Take a screenshot.", true);
	  	        Reporter.log("Screenshot captured: </br>" + imgTag, true);
	  	        Reporter.log(timestamp, true);

	  	        // adding the img to an array to be called on later
	  	        imgTags.add(imgTag);
	  	        
	  	    } catch (Exception ex) {
	  	        ex.printStackTrace();
	  	        
	  	        Reporter.log("Take a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	    }
	  	}


	    private String convertToBase64(File file) throws IOException {
	        byte[] fileContent = Files.readAllBytes(file.toPath());
	        return Base64.getEncoder().encodeToString(fileContent);
	    }
	

		private String getTimestamp() {
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		    return sdf.format(new Date());
		}
		
	  	public ArrayList<String> imgTags = new ArrayList<>();

	    // Getter method to access the imgTags ArrayList
	    public ArrayList<String> getImgTags() {
	        return imgTags;
	    }
	  	
	  	
		  //Hexagon test
	  	public void HexTest() {
	  	    try {
	  	    	HexUsername.sendKeys("NRODGERS@LEANBIOLOGIX.COM");
	  	    	Thread.sleep(2000);
	  	    	HexPassword.sendKeys("Password1");
	  	    	HexLoginButton.click();
	  	    	Thread.sleep(3000);
	  	    	HexWorkTab.click();
	  	    	Thread.sleep(1000);
	  	    	HexWorkOrders.click();
	  	    	Thread.sleep(3000);
	  	    	HexStatusFilter.sendKeys("Closed");
	  	    	Thread.sleep(3000);
	  	    	HexRun.click();
	  	    	Thread.sleep(5000);
	  	        refreshTimestamp();
	  	        Reporter.log("Go to Purchase Orders page.", true);
	  	        Reporter.log("Navigates to Purchase Orders page successfully.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Go to Purchase Orders page.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step1WOR() {
	  	    try {
	  	    	
	  	    	Thread.sleep(3000);
	  	    	
	  	    	HexUsername.sendKeys("NRODGERS@LEANBIOLOGIX.COM");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	HexPassword.sendKeys("Password1");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	HexLoginButton.click();
	  	    	Thread.sleep(4000);
	  	    	
	  	    	WorkDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	findElement("Work Orders", "-textEl", "click", "0");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusSearch.sendKeys("Work request");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderPrioritySearch.sendKeys("4");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderRunButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderSplitScreenButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderLocationField.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderLocationField.sendKeys(Keys.DELETE);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderLocationField.sendKeys("03");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Login to the target CMMS environment as an MDADMIN level user.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to the Work > Work Orders screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Query for and select a Work Order with Priority from P2 to P6 and in Status \"Work Request“.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Confirmed\r\n"
	  	        		+ "-Rejected\r\n"
	  	        		+ "\r\n"
	  	        		+ "Record the Work Order number and Organization.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Priority P2 to P6 Work Order is selected in Status Work Request.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that only the following status changes are available:\r\n"
	  	        		+ "-Confirmed\r\n"
	  	        		+ "-Rejected\r\n"
	  	        		+ "\r\n"
	  	        		+ "Work Order number and Organization are recorded.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Login to the target CMMS environment as an MDADMIN level user.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to the Work > Work Orders screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Query for and select a Work Order with Priority from P2 to P6 and in Status \"Work Request“.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Confirmed\r\n"
	  	        		+ "-Rejected\r\n"
	  	        		+ "\r\n"
	  	        		+ "Record the Work Order number and Organization.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step2WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderStatusField.sendKeys("Confirmed");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);	  	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Status field to Confirmed (change the value of the field to Confirmed and then select the Save Record toolbar button).\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order status is updated to Confirmed.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Status field to Confirmed (change the value of the field to Confirmed and then select the Save Record toolbar button).\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step3WOR() {
	  	    try {
	  	    	
	  	    	//WorkOrderStatusDropdown.click();
	  	    	//Thread.sleep(2000);
	  	    	
	  	    	//WorkOrderStatusDropdown.sendKeys(Keys.DOWN);
	  	    	//Thread.sleep(2000);
	  	    	
	  	    	//WorkOrderStatusDropdown.sendKeys(Keys.ENTER);
	  	    	//Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusField.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusField.sendKeys(Keys.DELETE);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusField.sendKeys("In Planning");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);	  
	  	    	
	  	    	WorkOrderStatusDropdown.click();
	  	    	Thread.sleep(2000);	 
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Status field to 'In Planning'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Deferred\r\n"
	  	        		+ "-Ready to be Scheduled\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order status is updated to 'In Planning'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that only the following status changes are available:\r\n"
	  	        		+ "-Deferred\r\n"
	  	        		+ "-Ready to be Scheduled\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Status field to 'In Planning'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Deferred\r\n"
	  	        		+ "-Ready to be Scheduled\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step4WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderActivitiesTab.click();
	  	    	Thread.sleep(4000);
	  	    	
	  	    	WorkOrderActivitiesTradeField.sendKeys("*");
	  	    	Thread.sleep(2000);	  
	  	    	
	  	    	WorkOrderActivitiesPeopleRequiredField.sendKeys("1");
	  	    	Thread.sleep(2000);	 
	  	    	
	  	    	WorkOrderActivitiesEstimatedHoursField.sendKeys("1");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderMoreDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderPartsTab.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderPartField.sendKeys("CONDUCTIVITY STANDARD");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderPartsTabActivityDropdown.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderPartsTabActivityDropdown.sendKeys(Keys.DOWN);
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderPartsTabActivityDropdown.sendKeys(Keys.ENTER);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStoreField.sendKeys("MSL-CS-BW");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderPlannedQtyField.sendKeys("1");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderReservedQtyField.sendKeys("1");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderPlannedSourceField.sendKeys("Direct Purchase");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Parts tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields and then select the Save Record toolbar button to add the Parts line to the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Parts line is added to the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Parts tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields and then select the Save Record toolbar button to add the Parts line to the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step5WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderRecordViewTab.click();
	  	    	Thread.sleep(2000);
	  	 
	  	    	WorkOrderStatusField.sendKeys("Deferred");
	  	    	Thread.sleep(2000);	 
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Record View tab. Update the Status field to Deferred.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only available status change is to 'In Planning'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order status is updated to Deferred.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that the only available status change is to 'In Planning'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Record View tab. Update the Status field to Deferred.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only available status change is to 'In Planning'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step6WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderRecordViewTab.click();
	  	    	Thread.sleep(2000);
	  	 
	  	    	WorkOrderStatusField.sendKeys("In Planning");
	  	    	Thread.sleep(2000);	 
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);	  	   
	  	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Status field to 'In Planning' again.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Status field is updated to 'In Planning' again.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Status field to 'In Planning' again.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step7WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderRecordViewTab.click();
	  	    	Thread.sleep(2000);
	  	 
	  	    	WorkOrderStatusField.sendKeys("Ready to be Scheduled");
	  	    	Thread.sleep(2000);	 
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);	  	   
	  	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Status field to 'Ready to be Scheduled'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that no status change is available on the Record View tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Status is updated to 'Ready to be Scheduled'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that no status change is available on the Record View tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Status field to 'Ready to be Scheduled'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that no status change is available on the Record View tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step8WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderScheduledLaborActivityDropdown.click();
	  	    	Thread.sleep(2000);
	  	 
	  	    	WorkOrderScheduledLaborActivityDropdown.sendKeys(Keys.ENTER);
	  	    	Thread.sleep(2000);	 
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);	 
	  	    	
	  	    	WorkOrderScheduledLaborYesButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Schedule Labor tab. Then complete the required fields and select the Save Record toolbar button to add the Scheduled Labor line to the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Labor is scheduled on the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Schedule Labor tab. Then complete the required fields and select the Save Record toolbar button to add the Scheduled Labor line to the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step9WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderRecordViewTab.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusDropdown.click();
	  	    	Thread.sleep(2000);	 
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Record View tab. Confirm that the Work Order was automatically promoted to Scheduled status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only available status change is to 'In Progress'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Confirmed that the Work Order was automatically promoted to Scheduled status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that the only available status change is to 'In Progress'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Record View tab. Confirm that the Work Order was automatically promoted to Scheduled status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only available status change is to 'In Progress'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step10WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderStatusField.sendKeys("In Progress");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderStatusDropdown.click();
	  	    	Thread.sleep(2000);	 
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Work Order status to 'In Progress'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-On Hold\r\n"
	  	        		+ "-Cancelled\r\n"
	  	        		+ "-Work Completed\r\n"
	  	        		+ "-Completed with Follow Up\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order status to is updated to 'In Progress'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that only the following status changes are available:\r\n"
	  	        		+ "-On Hold\r\n"
	  	        		+ "-Cancelled\r\n"
	  	        		+ "-Work Completed\r\n"
	  	        		+ "-Completed with Follow Up\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Update the Work Order status to 'In Progress'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-On Hold\r\n"
	  	        		+ "-Cancelled\r\n"
	  	        		+ "-Work Completed\r\n"
	  	        		+ "-Completed with Follow Up\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step11WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderDocumentsTab.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderDocumentsAddButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderDocumentField.sendKeys("101");
	  	    	Thread.sleep(2000);	 
	  	    	
	  	    	WorkOrderDocumentSaveButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderDocumentClick.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderDocumentView.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Documents tab of the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the Add Document toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields to attach a file from the local machine.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Then select Save.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Double-click on the attached filename. Confirm that a window with the document details appears.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the View Document button. Confirm that the document saves onto the local machine.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Document is added to the Work Order and then saved to the local machine from the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Documents tab of the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the Add Document toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields to attach a file from the local machine.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Then select Save.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Double-click on the attached filename. Confirm that a window with the document details appears.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the View Document button. Confirm that the document saves onto the local machine.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step12WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderExpandRight.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderStatusSearch.sendKeys("In Progress");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderPrioritySearch.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderPrioritySearch.sendKeys(Keys.DELETE);
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderRunButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSplitScreenButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderChecklistTab.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderChecklistPerformedBy.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderChecklistPassword1.sendKeys("Password1");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderChecklistOkButton1.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderChecklistReviewedBy.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderChecklistPassword2.sendKeys("Password1");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderChecklistOkButton2.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Select a new Work Order in the ‘In Progress‘ status with Activities and Checklist items.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to the Checklist tab of the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select each Activity line in the Activity dropdown field and ensure all checklist items are completed. Click the Submit (floppy disk icon) toolbar button to commit any input to checklists.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the button attached to the Performed By field and submit an eSignature with the tester's credentials.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the button attached to the Reviewed By field and submit an eSignature with the tester's credentials.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("New Work Order in ‘In Progress‘ status with Activities and Checklist items is selected.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Checklists for all Activities on the Work Order are completed.\r\n"
	  	        		+ "\r\n"
	  	        		+ "eSignatures are supplied in the 'Performed By' and 'Reviewed By' fields.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Select a new Work Order in the ‘In Progress‘ status with Activities and Checklist items.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to the Checklist tab of the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select each Activity line in the Activity dropdown field and ensure all checklist items are completed. Click the Submit (floppy disk icon) toolbar button to commit any input to checklists.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the button attached to the Performed By field and submit an eSignature with the tester's credentials.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the button attached to the Reviewed By field and submit an eSignature with the tester's credentials.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step13WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderBookLaborTab.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderBookLaborEmployee.sendKeys("COOLES");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderBookLaborDateWorked.sendKeys("02-JUL-2024");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderBookLaborYesButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderBookLaborHoursWorked.sendKeys("2");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Book Labor tab of the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the Add Labor toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields to book labor hours against one of the Activities completed on the Work Order. Then select the Save Record toolbar button to add the Booked Labor line to the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Labor is booked on the Work Order against a Work Order Activity.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Book Labor tab of the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the Add Labor toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields to book labor hours against one of the Activities completed on the Work Order. Then select the Save Record toolbar button to add the Booked Labor line to the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step14WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderRecordViewTab.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderStatusField.sendKeys("Work Completed");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderStatusDropdown.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Record View tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Update the Work Order status to 'Work Completed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only status change available is to 'Reviewed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order status is updated to 'Work Completed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that the only status change available is to 'Reviewed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Record View tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Update the Work Order status to 'Work Completed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only status change available is to 'Reviewed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step15WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderRecordViewSignature.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderRecordViewPassword.sendKeys("Password1");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderRecordViewOkButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusField.sendKeys("Reviewed");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Record View tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Update the Work Order status to 'Work Completed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only status change available is to 'Reviewed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order status is updated to 'Work Completed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that the only status change available is to 'Reviewed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Record View tab.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Update the Work Order status to 'Work Completed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only status change available is to 'Reviewed'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step16WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderExpandRight.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderStatusSearch.sendKeys("Work request");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderRunButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSplitScreenButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderRejectedReason.sendKeys("ANIS");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusField.sendKeys("Rejected");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Select a new Work Order record in 'Work Request' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the Reject Reason field.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Then update the Work Order status to Rejected.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order record in 'Work Request' status is selected.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Work Order is updated to Rejected status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Select a new Work Order record in 'Work Request' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the Reject Reason field.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Then update the Work Order status to Rejected.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step17WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderNewRecord.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderOrganization.sendKeys("BW");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderEquipment.sendKeys("01");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderLocationField.sendKeys("01");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderPriority.sendKeys("1");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderPriority.sendKeys(Keys.ENTER);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Select the New Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the Organization field and then complete all required fields to create a new Work Order. Ensure that the Priority is set to P1: '1 - EMERGENCY'. Then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Work Order is automatically promoted to the 'In Progress' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Priority P1 ('1 - Emergency) Work Order is automatically promoted to the 'In Progress' status upon manual creation of the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Select the New Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the Organization field and then complete all required fields to create a new Work Order. Ensure that the Priority is set to P1: '1 - EMERGENCY'. Then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Work Order is automatically promoted to the 'In Progress' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step18WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderExpandRight.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderStatusSearch.sendKeys("In Progress");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderRunButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSplitScreenButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderRecordViewSignature.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderRecordViewPassword.sendKeys("Password1");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderRecordViewOkButton.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderCancelReason.sendKeys("EOOS");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrderStatusSearch.sendKeys("Cancelled");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkOrderSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Select the New Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the Organization field and then complete all required fields to create a new Work Order. Ensure that the Priority is set to P1: '1 - EMERGENCY'. Then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Work Order is automatically promoted to the 'In Progress' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Priority P1 ('1 - Emergency) Work Order is automatically promoted to the 'In Progress' status upon manual creation of the Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Select the New Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the Organization field and then complete all required fields to create a new Work Order. Ensure that the Priority is set to P1: '1 - EMERGENCY'. Then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Work Order is automatically promoted to the 'In Progress' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step19WOR() {
	  	    try {
	  	    	
	  	    	WorkOrderPrintPreview.click();
	  	    	Thread.sleep(2000);	
	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Select the Print Preview toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Cofirm that a preview of the Work Order report prints, included the Work Order Number, Organization, Status (Cancelled), and supplied tester eSignature.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.\r\n"
	  	        		+ "", true);
	  	        Reporter.log("Print Preview functionality for Reporting confirmed to work as intended.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.\r\n"
	  	        		+ "", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Select the Print Preview toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Cofirm that a preview of the Work Order report prints, included the Work Order Number, Organization, Status (Cancelled), and supplied tester eSignature.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.\r\n"
	  	        		+ "", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step20WOR() {
	  	    try {
	  	    	
	  	    	WorkDropdown.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkReports.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkReportsPrintWorkOrders.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkReportsPrintWorkOrdersComprehensive.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkReportsWorkOrder.sendKeys("18115");
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkReportsPrintRecord.click();
	  	    	Thread.sleep(2000);	
	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Work > Reports > Print Work Orders > 'Print Work Order - Comprehensive' screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "In the Work Order field, enter the recorded Work Order number (from the first Work Order selected). Clear the Start and End Date fields and then click the Print Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Print Work Order report prints, and includes accurate Work Order data as well as Activity details associated with the relevant Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture screenshot(s).", true);
	  	        Reporter.log("Confirmed that the 'Print Work Order - Comprehensive' report prints for the selected Work Order, and includes accurate Work Order data as well as Activity details.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture screenshot(s).", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Work > Reports > Print Work Orders > 'Print Work Order - Comprehensive' screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "In the Work Order field, enter the recorded Work Order number (from the first Work Order selected). Clear the Start and End Date fields and then click the Print Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Print Work Order report prints, and includes accurate Work Order data as well as Activity details associated with the relevant Work Order.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture screenshot(s).", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step21WOR() {
	  	    try {
	  	    	
	  	    	WorkDropdown.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkSetup.click();
	  	    	Thread.sleep(2000);	
	  	    	
	  	    	WorkSetupEmployees.click();
	  	    	Thread.sleep(2000);		
	    	
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Work > Setup > Employees screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Ensure that the Job Title, Supervisor Code, and Schedule Group Class fields are available as Optional fields\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture screenshot.\r\n"
	  	        		+ "", true);
	  	        Reporter.log("Tester ensured the intended layout of Employee screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.\r\n"
	  	        		+ "", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Work > Setup > Employees screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Ensure that the Job Title, Supervisor Code, and Schedule Group Class fields are available as Optional fields\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture screenshot.\r\n"
	  	        		+ "", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		public void Step1WRR() {
	  	    try {
	  	    	
	  	    	Thread.sleep(3000);
	  	    	
	  	    	HexUsername.sendKeys("NRODGERS@LEANBIOLOGIX.COM");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	HexPassword.sendKeys("Password1");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	HexLoginButton.click();
	  	    	Thread.sleep(4000);
	  	    	
	  	    	OperationsDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	OperationsCallCenter.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	CallCenterNewRecord.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	CallCenterOrganization.sendKeys("*");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	CallCenterEquipment.click();
	  	    	Thread.sleep(2000);
	  	    	CallCenterEquipment.sendKeys("01-01-059");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	CallCenterServiceCode.sendKeys("A");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	CallCenterLocation.sendKeys("01");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	CallCenterContactInfoDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	CallCenterEmail.sendKeys("nrodgers@leanbiologix.com");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	CallCenterSaveButton.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Login to the target CMMS environment as an MDADMIN level user.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to screen Operations > Call Center.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields. Ensure the Equipment field and Service Code fields are  complete such that Service Code is 'A'. Select the Save Record toolbar button to create the Service Request. \r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that WO Priority automatically changes to '1 - Emergency'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Record the e-mail address of the Caller.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Call Center record created with Service Code is 'A'. \r\n"
	  	        		+ "\r\n"
	  	        		+ "Tester confirms that WO Priority automatically changed to '1 - Emergency'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "E-mail address of the Caller is recorded.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Login to the target CMMS environment as an MDADMIN level user.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to screen Operations > Call Center.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields. Ensure the Equipment field and Service Code fields are  complete such that Service Code is 'A'. Select the Save Record toolbar button to create the Service Request. \r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that WO Priority automatically changes to '1 - Emergency'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Record the e-mail address of the Caller.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
		
		public void Step2WRR() {
	  	    try {
	  	    	
	  	    	WorkDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkWorkRequests.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkRequestsRequestedBy.sendKeys("KMIRZA");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkRequestsSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Work > Work Request screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that a Work Request was created in Priority '1 - EMERGENCY' for the Service Request. Complete the 'Reported By' field and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Record the Work Request number.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Navigate to the Work > Work Request screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that a Work Request was created in Priority '1 - EMERGENCY' for the Service Request. Complete the 'Reported By' field and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Work Request number is recorded.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Work > Work Request screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that a Work Request was created in Priority '1 - EMERGENCY' for the Service Request. Complete the 'Reported By' field and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Record the Work Request number.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
		
		public void Step3WRR() {
	  	    try {
	  	    	
	  	    	Thread.sleep(3000);
	  	    	
	  	    	AdministrationDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AdministrationEmailMessenger.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	findElement("E-mail Viewer", "-textEl", "click", "0");
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Administration > E-Mail Messenger > E-Mail Viewer screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the latest E-Mail message and confirm that it details an outbound P1 Work Request to Maintenance.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("E-Mail message is sent detailing outbound P1 Work Request to Maintenance.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Administration > E-Mail Messenger > E-Mail Viewer screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the latest E-Mail message and confirm that it details an outbound P1 Work Request to Maintenance.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
		
		public void Step4WRR() {
	  	    try {
	  	    	
	  	    	Thread.sleep(3000);
	  	    	
	  	    	WorkDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	findElement("Work Orders", "-textEl", "click", "0");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersSplitScreen.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersStatusDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to screen Work > Work Orders.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Using the recorded Work Reques number, query for and select the resulting Work Order. Confirm that it is in 'Work Request' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only available status changes are to Rejected or Confirmed.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Reported By field value carries over from the Work Request.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Confirmed that the only available Work Order status changes are to Rejected or Confirmed from 'Work Request'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Reported By field value automatically carries over from the Work Request.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to screen Work > Work Orders.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Using the recorded Work Reques number, query for and select the resulting Work Order. Confirm that it is in 'Work Request' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only available status changes are to Rejected or Confirmed.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Reported By field value carries over from the Work Request.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		public void Step5WRR() {
	  	    try {
	  	    	
	  	    	//WorkOrdersStatusDropdown.click();
	  	    	//Thread.sleep(1000);
	  	    	
	  	    	//WorkOrdersStatus.click();
	  	    	//Thread.sleep(2000);
	  	    	
	  	    	//WorkOrdersStatus.sendKeys("Rejected");
	  	    	//Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersStatus.sendKeys(Keys.UP);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersStatus.sendKeys(Keys.ENTER);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersOKError.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Change the Status to Rejected and select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the update fails and that a message appears asserting that a Reject Reason be provided.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order update to 'Reject' status fails and a message appears asserting that a Reject Reason be provided.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Change the Status to Rejected and select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the update fails and that a message appears asserting that a Reject Reason be provided.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
		
		public void Step6WRR() {
	  	    try {

	  	    	WorkOrdersResetButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersRejectedReason.sendKeys("ANIS");
	  	    	//findElement("Rejected Reason:", "-inputEl", "sendkeys", "ANIS");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersStatusDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersStatus.sendKeys(Keys.UP);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersStatus.sendKeys(Keys.ENTER);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	WorkOrdersStatusDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Completed the Rejected Reason field and then change the status back to Rejected. Select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the status change commits and that no other status changes are available.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Order status change to 'Reject' commits and no other status changes are available.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Completed the Rejected Reason field and then change the status back to Rejected. Select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the status change commits and that no other status changes are available.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
		
		public void Step7WRR() {
	  	    try {
	  	    	
	  	    	Thread.sleep(3000);
	  	    	
	  	    	findElement("Administration", "-btnInnerEl", "click", "0");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	findElement("E-Mail Messenger", "-textEl", "click", "0");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	findElement("E-mail Viewer", "-textEl", "click", "0");
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Administration > E-Mail Messenger > E-Mail Viewer screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the latest E-Mail message and confirm that it is an outbound e-mail addressed to the Caller of the previous Service Request and details that the Work Request was rejected.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("E-mail is sent to the Caller of the previous Service Request, detailing that the Work Request was rejected.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Navigate to the Administration > E-Mail Messenger > E-Mail Viewer screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the latest E-Mail message and confirm that it is an outbound e-mail addressed to the Caller of the previous Service Request and details that the Work Request was rejected.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
		
		public void Step8WRR() {
	  	    try {
	  	    	
	  	    	Thread.sleep(3000);
	  	    	
	  	    	WorkDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	WorkWorkRequests.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	WorkOrdersSplitScreen.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Work > Work Request screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the previously selected Work Request record and confirm that the status has updated to that of the associated Work Order (Rejected).\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Work Request Status automatically updated to Rejected.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Return to the Work > Work Request screen.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Select the previously selected Work Request record and confirm that the status has updated to that of the associated Work Order (Rejected).\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
		

	  	public void Step1ER() {
	  	    try {
	  	    	
	  	    	Thread.sleep(3000);
	  	    	
	  	    	HexUsername.sendKeys("NRODGERS@LEANBIOLOGIX.COM");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	HexPassword.sendKeys("Password1");
	  	    	Thread.sleep(2000);
	  	    	
	  	    	HexLoginButton.click();
	  	    	Thread.sleep(4000);
	  	    	
	  	    	EquipmentDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetsOnEquipmentDropdown.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	NewRecordOnAssets.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetIDField.sendKeys("TEST027");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetDescription.sendKeys("test description");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetDepartment.sendKeys("*");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetStatus.sendKeys("Entering Data");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetParentAsset.sendKeys("10000");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetStatus.click();
	  	    	AssetStatus.sendKeys("Awaiting Verification");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetStatus.click();
	  	    	AssetStatus.sendKeys("Installed");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetStatusDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Log into the target CMMS environment as an MDADMIN user.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to an Equipment screen (menu path: Equipment > Assets, Positions, or Systems).\r\n"
	  	        		+ "\r\n"
	  	        		+ "Then select the New Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields to add an Equipment record. Specify a Parent Asset using the Parent Asset field. Then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Equipment record was created into the “Entering Data” status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Promote the Equipment record through the “Awaiting Verification” to the “Installted” status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Then confirm that only the following status changes are available:\r\n"
	  	        		+ "-Awaiting Verification\r\n"
	  	        		+ "-Removed from Service\r\n"
	  	        		+ "-Decommissioned\r\n"
	  	        		+ "\r\n"
	  	        		+ "Record the Equipment number, the Parent Asset number, and tje Organization.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("New Equipment record is created into 'Installed' status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Awaiting Verification\r\n"
	  	        		+ "-Removed from Service\r\n"
	  	        		+ "-Decommissioned\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Log into the target CMMS environment as an MDADMIN user.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to an Equipment screen (menu path: Equipment > Assets, Positions, or Systems).\r\n"
	  	        		+ "\r\n"
	  	        		+ "Then select the New Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Complete the required fields to add an Equipment record. Specify a Parent Asset using the Parent Asset field. Then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the Equipment record was created into the “Entering Data” status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Promote the Equipment record through the “Awaiting Verification” to the “Installted” status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Then confirm that only the following status changes are available:\r\n"
	  	        		+ "-Awaiting Verification\r\n"
	  	        		+ "-Removed from Service\r\n"
	  	        		+ "-Decommissioned\r\n"
	  	        		+ "\r\n"
	  	        		+ "Record the Equipment number, the Parent Asset number, and tje Organization.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	
	  	public void Step2ER() {
	  	    try {
	  	    	
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.click();
	  	    	AssetStatus.sendKeys(Keys.ARROW_DOWN);
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.sendKeys(Keys.ENTER);
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetStatusDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment to 'Removed from Service' and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Decommissioned\r\n"
	  	        		+ "-Installed\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Equipment status is updated to 'Removed from Service'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that only the following status changes are available:\r\n"
	  	        		+ "-Decommissioned\r\n"
	  	        		+ "-Installed\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment to 'Removed from Service' and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Decommissioned\r\n"
	  	        		+ "-Installed\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step3ER() {
	  	    try {
	  	    	
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.click();
	  	    	AssetStatus.sendKeys(Keys.ARROW_UP);
	  	    	AssetStatus.sendKeys(Keys.ARROW_UP);
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.sendKeys(Keys.ENTER);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetStatusOK.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetStatusDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment to Decommissioned and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only status change available is back to the Installed status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Equipment status is updated to Decommissioned.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that the only status change available is back to the Installed status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment to Decommissioned and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only status change available is back to the Installed status.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step4ER() {
	  	    try {
	  	    	
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.click();
	  	    	AssetStatus.sendKeys(Keys.ARROW_DOWN);
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.sendKeys(Keys.ENTER);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetStatusDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment back to Installed and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Equipment status is updated to Installed.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment back to Installed and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step5ER() {
	  	    try {
	  	    	
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.click();
	  	    	AssetStatus.sendKeys(Keys.ARROW_UP);
	  	    	AssetStatus.sendKeys(Keys.ARROW_UP);
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.sendKeys(Keys.ENTER);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetStatusDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment to 'Awaiting Verification' and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Entering Data\r\n"
	  	        		+ "-Installed\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Equipment status is updated to 'Awaiting Verification'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that only the following status changes are available:\r\n"
	  	        		+ "-Entering Data\r\n"
	  	        		+ "-Installed\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment to 'Awaiting Verification' and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that only the following status changes are available:\r\n"
	  	        		+ "-Entering Data\r\n"
	  	        		+ "-Installed\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step6ER() {
	  	    try {
	  	    	
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.click();
	  	    	AssetStatus.sendKeys(Keys.ARROW_DOWN);
	  	    	Thread.sleep(1000);
	  	    	AssetStatus.sendKeys(Keys.ENTER);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetStatusDropdown.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment to 'Entering Data' and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only status change available is back to 'Awaiting Verification'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Equipment status is updated to 'Entering Data'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirmed that the only status change available is back to 'Awaiting Verification'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Change the status of the Equipment to 'Entering Data' and then select the Save Record toolbar button.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Confirm that the only status change available is back to 'Awaiting Verification'.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step7ER() {
	  	    try {
	  	    	
	  	    	AssetPartDropdown.click();
	  	    	AssetPart.sendKeys("AIR STANDARD");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetLocation.sendKeys("01-01-059");
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetSaveButton.click();
	  	    	Thread.sleep(2000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Associate a Part record using the Part field and specify a Location in the Location field.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Part and Location data are added to the Equipment record.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Associate a Part record using the Part field and specify a Location in the Location field.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  	public void Step8ER() {
	  	    try {
	  	    	
	  	    	AssetExpandRightView.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetSearchField.click();
	  	    	AssetSearchField.sendKeys("10000");
	  	    	AssetSearchField.sendKeys(Keys.ENTER);
	  	    	Thread.sleep(2000);
	  	    	
	  	    	AssetSplitView.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	    	AssetStructure.click();
	  	    	Thread.sleep(1000);
	  	    	
	  	        refreshTimestamp();
	  	        Reporter.log("Enter List View, and then query for and select the Parent Asset using the recorded Parent Asset number.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to the Structure tab. Then confirm that a system hierarchy is displayed showing the previously selected Equipment record appearing as a child to the Parent Asset record.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Confirmed that a system hierarchy is displayed showing the previously selected Equipment record appearing as a child to the Parent Asset record.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Screenshot attached.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Enter List View, and then query for and select the Parent Asset using the recorded Parent Asset number.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Navigate to the Structure tab. Then confirm that a system hierarchy is displayed showing the previously selected Equipment record appearing as a child to the Parent Asset record.\r\n"
	  	        		+ "\r\n"
	  	        		+ "Capture a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
}
